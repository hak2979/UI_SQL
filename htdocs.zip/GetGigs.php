<?php
$servername = "localhost";
$username = "admin";
$password = "1234"; // Password for MySQL, if set
$dbname = "hak"; // Name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the uid from the request
$uid = $_GET['uid']; // Assuming you're receiving the uid via GET

// SQL query to select all data from the "gig" table excluding the specified uid
$sql = "SELECT * FROM gig WHERE id != '$uid'";

// Execute the query
$result = $conn->query($sql);

// Initialize an array to store gig data
$gigs = array();

// Check if any rows were returned
if ($result->num_rows > 0) {
    // Loop through each row and store the data in the $gigs array
    while($row = $result->fetch_assoc()) {
        $gig = array(
            "des" => $row["des"],
            "field" => $row["field"],
            "job" => $row["job"],
            "session" => $row["session"],
            "id" => $row["id"]
        );
        $gigs[] = $gig;
    }
} else {
    echo json_encode(array("message" => "No gigs found")); // Return a JSON response indicating no gigs found
}

// Close connection
$conn->close();

// Return the gigs array as JSON
echo json_encode($gigs);
?>