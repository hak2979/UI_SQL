<?php
$servername = "localhost";
$username = "admin";
$password = "1234"; // Password for MySQL, if set
$dbname = "hak"; // Name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Extract data sent via POST request
$uid = $_POST['uid'];
$email= $_POST['email'];

// SQL query to update user email in the Users table
$sql = "UPDATE Users SET email='$email' WHERE id='$uid'";

// Execute the query
if ($conn->query($sql) === TRUE) {
    echo "success";
} else {
    echo "Error updating email: " . $conn->error;
}

// Close connection
$conn->close();
?>