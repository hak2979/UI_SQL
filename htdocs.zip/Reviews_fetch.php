<?php
$servername = "localhost";
$username = "admin";
$password = "1234"; // Password for MySQL, if set
$dbname = "hak"; // Name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the id parameter exists and is not empty
if (isset($_GET["id"]) && !empty($_GET["id"])) {
    // Get the id parameter
    $id = $_GET["id"];
    
    // SQL query to select data from the "gig" table where id matches the specified id
    $sql = "SELECT * FROM Reviews WHERE user_to = $id";

    // Execute the query
    $result = $conn->query($sql);

    // Initialize an array to store gig data
    $gigs = array();

    // Check if any rows were returned
    if ($result->num_rows > 0) {
        // Loop through each row and store the data in the $gigs array
        while($row = $result->fetch_assoc()) {
            $gig = array(
                "name" => $row["name"],
                "review" => $row["review"],
                "stars" => $row["stars"],
                "user_from" => $row["user_from"],
                "user_to" => $row["user_to"]
            );
            $gigs[] = $gig;
        }
        // Return the gigs array as JSON
        echo json_encode($gigs);
    } else {
        // No gigs found with the specified id
        echo json_encode(array("message" => "No gigs found for the specified ID"));
    }
} else {
    // ID parameter is missing or empty
    echo json_encode(array("error" => "ID parameter is missing or empty"));
}

// Close connection
$conn->close();
?>