<?php
$servername = "localhost";
$username = "admin";
$password = "1234"; // Password for MySQL, if set
$dbname = "hak"; // Name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to select all data from the "contacts" table
$sql = "SELECT * FROM contacts";

// Execute the query
$result = $conn->query($sql);

// Initialize an array to store contact data
$contacts = array();

// Check if any rows were returned
if ($result->num_rows > 0) {
    // Loop through each row and store the data in the $contacts array
    while($row = $result->fetch_assoc()) {
        $contact = array(
            "name" => $row["name"],
            "rollno" => $row["rollno"]
        );
        $contacts[] = $contact;
    }
} else {
    echo json_encode(array("message" => "No contacts found")); // Return a JSON response indicating no contacts found
}

// Close connection
$conn->close();

// Return the contacts array as JSON
echo json_encode($contacts);
?>