<?php
$servername = "localhost";
$username = "admin";
$password = "1234"; // Password for MySQL, if set
$dbname = "hak"; // Name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Extract data sent via POST request
$id = $_POST['id'];

// SQL query to insert data into the "UserInfo" table
$sql = "Select img_b from UserInfo where id='$id'";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    // Fetch the result row as an associative array
    $row = $result->fetch_assoc();
    
    // Extract the id value
    $img = $row['img_b'];
    
    // Output the id
    echo $img;
} else {
    // No rows found or error executing the query
    echo "Error from GetName";
}

// Close connection
$conn->close();
?>