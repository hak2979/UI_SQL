<?php
$servername = "localhost";
$username = "admin";
$password = "1234"; // Password for MySQL, if set
$dbname = "hak"; // Name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Extract data sent via POST request
$city = $_POST['city'];
$country = $_POST['country'];
$email = $_POST['email'];
$fcmtoken = $_POST['fcmtoken'];
$img = $_POST['img'];
$img_b = $_POST['img_b'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$id = $_POST['id'];

// SQL query to insert data into the "UserInfo" table
$sql = "INSERT INTO UserInfo (city, country, email, fcmtoken, img, img_b, name, phone, id) VALUES ('$city', '$country', '$email', '$fcmtoken', '$img', '$img_b', '$name', '$phone', '$id')";

// Execute the query
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close connection
$conn->close();
?>