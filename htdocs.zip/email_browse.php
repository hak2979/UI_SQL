<?php
$servername = "localhost";
$username = "admin";
$password = "1234"; // Password for MySQL, if set
$dbname = "hak"; // Name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Extract data sent via POST request
$email = $_POST['email'];

// SQL query to check if email exists in Users table
$sql = "SELECT id FROM Users WHERE email='$email'";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    // Email found, return a response indicating existence
    echo "exists";
} else {
    // Email not found, return an empty response
    echo "";
}

// Close connection
$conn->close();
?>