<?php
$servername = "localhost";
$username = "admin";
$password = "1234"; // Password for MySQL, if set
$dbname = "hak"; // Name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Extract data sent via POST request
$email = $_POST['email'];
$password = $_POST['password'];

// SQL query to insert data into the "UserInfo" table
$sql = "Select id from Users where email='$email' and password='$password'";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    // Fetch the result row as an associative array
    $row = $result->fetch_assoc();
    
    // Extract the id value
    $id = $row['id'];
    
    // Output the id
    echo $id;
} else {
    // No rows found or error executing the query
    echo "No user found with the provided credentials";
}

// Close connection
$conn->close();
?>