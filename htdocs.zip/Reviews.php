<?php
$servername = "localhost";
$username = "admin";
$password = "1234"; // Password for MySQL, if set
$dbname = "hak"; // Name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Extract data sent via POST request
$name = $_POST['name'];
$review = $_POST['review'];
$stars = $_POST['stars'];
$user_from = $_POST['user_from'];
$user_to = $_POST['user_to'];

// SQL query to insert data into the "UserInfo" table
$sql = "INSERT INTO Reviews (name, review, stars, user_from, user_to) VALUES ('$name', '$review', '$stars', '$user_from', '$user_to')";

// Execute the query
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close connection
$conn->close();
?>