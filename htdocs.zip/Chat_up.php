<?php
$servername = "localhost";
$username = "admin";
$password = "1234";
$dbname = "hak";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Extract data sent via POST request
$msg_num = $_POST['mn'];
$msg= $_POST['msg'];

// SQL query to update the chat message with the specified msgid
$sql = "UPDATE Chats SET msg='$msg' WHERE msgid='$msg_num'";

// Execute the query
if ($conn->query($sql) === TRUE) {
    echo "success";
} else {
    echo "Error updating message: " . $conn->error;
}

// Close connection
$conn->close();
?>