<?php
$servername = "localhost";
$username = "admin";
$password = "1234"; // Password for MySQL, if set
$dbname = "hak"; // Name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Extract data sent via POST request
$fcmtoken = $_POST['fcmtoken'];
$id = $_POST['id'];

// SQL query to insert data into the "UserInfo" table
$sql = "UPDATE UserInfo SET fcmtoken='$fcmtoken' WHERE id='$id'";
        if ($conn->query($sql) === TRUE) {
            // FCM token updated successfully
            echo "Token updated successfully";
        } else {
            // Failed to update FCM token
            echo "Error: " . $conn->error;
        }
// Close connection
$conn->close();
?>