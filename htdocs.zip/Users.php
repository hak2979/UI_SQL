<?php
$servername = "localhost";
$username = "admin";
$password = "1234";
$dbname = "hak";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Extract data sent via POST request
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

// Check if email and password are not empty
if (!empty($email) && !empty($password)) {
    // Escape special characters to prevent SQL injection
    $email = $conn->real_escape_string($email);
    $password = $conn->real_escape_string($password);

    // SQL query to insert email and password into the "Users" table
    $sql = "INSERT INTO Users (email, password) VALUES ('$email', '$password')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        // Get the ID of the inserted row
        $userId = $conn->insert_id;
        echo $userId; // Return the ID of the inserted row
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Error: Email and password cannot be empty.";
}

// Close connection
$conn->close();
?>