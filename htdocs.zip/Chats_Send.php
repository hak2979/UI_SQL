<?php
$servername = "localhost";
$username = "admin";
$password = "1234"; // Password for MySQL, if set
$dbname = "hak"; // Name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Extract data sent via POST request
$msg = $_POST['msg'];
$msgType = $_POST['msgType'];
$recv = $_POST['recv'];
$sender = $_POST['sender'];
$timestamp = $_POST['timestamp'];

// SQL query to insert data into the "UserInfo" table
$sql = "INSERT INTO Chats (msg, msgType, recv, sender, timestamp) VALUES ('$msg', '$msgType', '$recv', '$sender', '$timestamp')";

// Execute the query
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close connection
$conn->close();
?>