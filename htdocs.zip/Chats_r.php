<?php
$servername = "localhost";
$username = "admin";
$password = "1234";
$dbname = "hak";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Extract data sent via GET request
$currentUser = $_GET['currentUser'];
$to_user = $_GET['to_user'];

// SQL query to select chat messages for the current user and the specified recipient
$sql = "SELECT * FROM Chats WHERE (sender='$currentUser' AND recv='$to_user') OR (sender='$to_user' AND recv='$currentUser')";

// Execute the query
$result = $conn->query($sql);

// Initialize an array to store chat messages
$messages = array();

// Check if any rows were returned
if ($result) {
    // Loop through each row and store the data in the $messages array
    while ($row = $result->fetch_assoc()) {
        $message = array(
            "sender" => $row["sender"],
            "recv" => $row["recv"],
            "msg" => $row["msg"],
            "msgType" => $row["msgType"],
            "msgid" => $row["msgid"],
            "timestamp" => $row["timestamp"]
        );
        $messages[] = $message;
    }
    // Close result set
    $result->close();
} else {
    // Handle query error
    echo json_encode(array("error" => "Error executing query: " . $conn->error));
}

// Close connection
$conn->close();

// Return the messages array as JSON
echo json_encode($messages);
?>