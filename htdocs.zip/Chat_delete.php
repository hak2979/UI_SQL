<?php
$servername = "localhost";
$username = "admin";
$password = "1234";
$dbname = "hak";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Extract data sent via POST request
$msg_num = $_POST['mn'];

// SQL query to delete the chat message with the specified msgid
$sql = "DELETE FROM Chats WHERE msgid='$msg_num'";

// Execute the query
if ($conn->query($sql) === TRUE) {
    echo "success";
} else {
    echo "Error deleting message: " . $conn->error;
}

// Close connection
$conn->close();
?>