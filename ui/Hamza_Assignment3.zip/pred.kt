package com.example.ui

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.FirebaseStorage
import com.squareup.picasso.Picasso
import com.squareup.picasso.Transformation

class pred : AppCompatActivity() {
    private var name_gigs= arrayOf("John Cooper","Martin Wat","Emma","Wills")
    private var price_gigs= arrayOf("$1500/Session","$500/Session","$109/Session","$80/Session",)
    private var Experience_gigs= arrayOf("UX Designer","Lead - Technolgy","Lead Corporation","@Meta")
    private var availible_gigs= arrayOf(true,false,false,false)
    private var categories= arrayOf("All","Education","Entreprenuership","Personal Growth","Caree","Etaaa")
    private var lik= arrayOf(true,true,true,true)
    private lateinit var auth: FirebaseAuth
    private lateinit var db: DatabaseReference
    private lateinit var storageref: FirebaseStorage
    private lateinit var selectedImageUri: Uri
    private lateinit var imgLauncher: ActivityResultLauncher<String>
    private lateinit var bimgLauncher: ActivityResultLauncher<String>
    private lateinit var bselectedImageUri: Uri
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pred)

        auth = FirebaseAuth.getInstance()
        storageref = FirebaseStorage.getInstance()

        // Register the activity result launcher
        imgLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                val i = findViewById<ImageView>(R.id.editprofile_img)
                i.setImageURI(it)
                selectedImageUri = it
            }
        }

        bimgLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                val i = findViewById<ImageView>(R.id.wp)
                i.setImageURI(it)
                bselectedImageUri = it
                uploadImage(bselectedImageUri)
            }
        }


        retrieveImageFromFirebase()
        retrieveImageFromFirebase_()
        val gigsLayout = findViewById<LinearLayout>(R.id.liked_card)
        for (i in name_gigs.indices) {

            val gigLayout = layoutInflater.inflate(R.layout.card_fiver,null)
            val nameTextView = gigLayout.findViewById<TextView>(R.id.name_service)
            val rateTextView = gigLayout.findViewById<TextView>(R.id.rate_service)
            val experienceTextView = gigLayout.findViewById<TextView>(R.id.Experience_of_parent)
            val availibilityTextView = gigLayout.findViewById<TextView>(R.id.is_availibil)
            val imageButton = gigLayout.findViewById<ImageButton>(R.id.imageButton_of_parent)


            imageButton.setBackgroundResource(R.drawable.heart_solid)
            nameTextView.text = name_gigs[i]
            rateTextView.text = price_gigs[i]
            experienceTextView.text = Experience_gigs[i]
            if (availible_gigs[i])
            {
                availibilityTextView.text ="Available"
                val greenColor = android.graphics.Color.parseColor("#00FF00")
                availibilityTextView.setTextColor(greenColor)
            } else
            {
                availibilityTextView.text ="Not Availible"
            }

            imageButton.setOnClickListener {
                if(lik[i]==false)
                {
                    imageButton.setBackgroundResource(R.drawable.heart_solid)
                    lik[i]=true
                }
                else{
                    imageButton.setBackgroundResource(R.drawable.heart_regular)
                    lik[i]=false
                }
            }
            gigLayout.setOnClickListener{
                Toast.makeText(this, "Press", Toast.LENGTH_SHORT).show()
                val intent= Intent(this,Detail::class.java)
                startActivity(intent)
            }

            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(10,0,10,0)
            gigLayout.layoutParams=params

            gigsLayout.addView(gigLayout)
        }

        val l=findViewById<LinearLayout>(R.id.reve_ar)
        val currentUser = auth.currentUser
        if(currentUser != null) {
            val userId = currentUser.uid
            db = FirebaseDatabase.getInstance().getReference().child("Users").child(userId).child("Reviews")
            db.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    for (userSnapshot in snapshot.children) {
                        val gig = layoutInflater.inflate(R.layout.revie, null)
                        val name = gig.findViewById<TextView>(R.id.reve_name)
                        val stars = gig.findViewById<RatingBar>(R.id.reve_ratingBar)
                        val feed = gig.findViewById<TextView>(R.id.reve_feed)

                        name.text = userSnapshot.child("name").getValue(String::class.java) ?: ""
                        stars.rating = userSnapshot.child("stars").getValue(Float::class.java) ?: 0f
                        feed.text = userSnapshot.child("user_from").getValue(String::class.java) ?: ""

                        val params = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                        params.setMargins(10, 0, 10, 0)
                        gig.layoutParams = params
                        l.addView(gig)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Handle onCancelled
                }
            })
        } else {
            // Handle the case when currentUser is null
        }
    }
    fun edi(view: View)
    {
        val intent=Intent(this,Edit_pro::class.java)
        startActivity(intent)
    }
    fun end_ac(view: View)
    {
        finish()
    }
    fun Book(view: View)
    {
        val intent=Intent(this,Bookedd::class.java)
        startActivity(intent)
    }
    fun home_screen(view: View)
    {
        val intent=Intent(this,Main_UI::class.java)
        startActivity(intent)
        finish()
    }
    fun Searc_screen(view: View)
    {
        val intent=Intent(this,Search::class.java)
        startActivity(intent)
        finish()
    }
    fun Plus_screen(view: View)
    {
        val intent=Intent(this,Add_t::class.java)
        startActivity(intent)
        finish()
    }
    fun Chat_screen(view: View)
    {
        val intent=Intent(this,chat_main::class.java)
        startActivity(intent)
        finish()
    }
    fun retrieveImageFromFirebase() {
        val currentUser = auth.currentUser
        currentUser?.let { user ->
            db = FirebaseDatabase.getInstance().getReference().child("Users").child(user.uid).child("UserInfo")
            db.get().addOnSuccessListener { dataSnapshot ->
                if (dataSnapshot.exists()) {
                    val imageUrl = dataSnapshot.child("img").value.toString()

                    // Load a circular placeholder image
                    val placeholderDrawable = getCirclePlaceholderDrawable()

                    // Load the retrieved image into ImageView as a round image using Picasso
                    val i = findViewById<ImageView>(R.id.pic)
                    Picasso.get()
                        .load(imageUrl)
                        .placeholder(placeholderDrawable)
                        .transform(Edit_pro.CircleTransform())
                        .into(i)
                }
            }.addOnFailureListener { exception ->
                Toast.makeText(this, "Failed to retrieve image: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    class CircleTransform : Transformation {
        override fun transform(source: Bitmap): Bitmap {
            val size = Math.min(source.width, source.height)

            val x = (source.width - size) / 2
            val y = (source.height - size) / 2

            val squaredBitmap = Bitmap.createBitmap(source, x, y, size, size)
            if (squaredBitmap != source) {
                source.recycle()
            }

            val bitmap = Bitmap.createBitmap(size, size, source.config)

            val canvas = Canvas(bitmap)
            val paint = Paint()
            val shader = BitmapShader(squaredBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            paint.shader = shader
            paint.isAntiAlias = true

            val radius = size / 2f
            canvas.drawCircle(radius, radius, radius, paint)

            squaredBitmap.recycle()
            return bitmap
        }

        override fun key(): String {
            return "circle"
        }
    }
    fun pic_select(view: View) {
        // Launch the image selection activity
        bimgLauncher.launch("image/*")
    }

    fun uploadImage(imageUri: Uri) {
        val imageRef = storageref.reference.child("images/${imageUri.lastPathSegment}")
        val uploadTask = imageRef.putFile(imageUri)
        uploadTask.addOnSuccessListener { taskSnapshot ->
            imageRef.downloadUrl.addOnSuccessListener { uri ->
                val imageUrl = uri.toString()
                val currentUser = auth.currentUser
                currentUser?.let { user ->
                    db = FirebaseDatabase.getInstance().getReference().child("Users").child(user.uid).child("UserInfo")
                    db.child("img_b").setValue(imageUrl)
                        .addOnSuccessListener {
                            Toast.makeText(this, "Image upload success", Toast.LENGTH_SHORT).show()
                            val i = findViewById<ImageView>(R.id.wp)
                            Picasso.get()
                                .load(imageUrl)
                                .fit()
                                .centerCrop()
                                .into(i)
                        }
                        .addOnFailureListener { error ->
                            Toast.makeText(this, "Failed to update image: ${error.message}", Toast.LENGTH_SHORT).show()
                        }
                }
            }
        }.addOnFailureListener { exception ->
            Toast.makeText(this, "Image upload failed: ${exception.message}", Toast.LENGTH_SHORT).show()
        }
    }
    fun retrieveImageFromFirebase_() {
        val currentUser = FirebaseAuth.getInstance().currentUser
        currentUser?.let { user ->
            val db = FirebaseDatabase.getInstance().getReference().child("Users").child(user.uid).child("UserInfo")
            db.get().addOnSuccessListener { dataSnapshot ->
                if (dataSnapshot.exists()) {
                    val imageUrl = dataSnapshot.child("img_b").value.toString()

                    // Load the retrieved image into ImageView as a round image using Glide
                    val imageView = findViewById<ImageView>(R.id.wp)
                    Picasso.get()
                        .load(imageUrl)
                        .fit()
                        .centerCrop()
                        .into(imageView)
                }
            }.addOnFailureListener { exception ->
                Toast.makeText(this, "Failed to retrieve image: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    fun getCirclePlaceholderDrawable(): Drawable {
        // Create a circular placeholder drawable
        val size = 300 // Set the size of the placeholder circle
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint().apply {
            isAntiAlias = true
            color = Color.LTGRAY // Set the color of the circular placeholder
        }
        val radius = size / 2f
        canvas.drawCircle(radius, radius, radius, paint)
        return BitmapDrawable(resources, bitmap)
    }
}