package com.example.ui

class User(
    var name: String? = "",
    var phone: String? = "",
    var email: String? = "",
    var country: String? = "",
    var city: String? = "",
    var img:String="https://firebasestorage.googleapis.com/v0/b/uial-ef265.appspot.com/o/images%2Fimage%3A56132?alt=media&token=e9f1650e-8d7a-40af-9209-e9feaa5ff816",
    var img_b:String="https://firebasestorage.googleapis.com/v0/b/uial-ef265.appspot.com/o/images%2Fimage%3A55373?alt=media&token=eb9a7a7f-f547-43e1-9581-c6c41c2b9389",
    var fcmtoken:String?=""
) {

}