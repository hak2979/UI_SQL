package com.example.ui

import java.util.Date

class Booking(
    var uid_from:String?="",
    var uid_to:String?="",
    var date: String?="",
    var time:String?="",
) {
}