package com.example.ui
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.squareup.picasso.Picasso
import com.squareup.picasso.Transformation

class Edit_pro : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var db: DatabaseReference
    private lateinit var storageref: FirebaseStorage
    private lateinit var selectedImageUri: Uri
    private lateinit var imgLauncher: ActivityResultLauncher<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_pro)

        auth = FirebaseAuth.getInstance()
        storageref = FirebaseStorage.getInstance()

        // Register the activity result launcher
        imgLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                val i = findViewById<ImageView>(R.id.editprofile_img)
                i.setImageURI(it)
                selectedImageUri = it
                uploadImage(selectedImageUri)
            }
        }

        retrieveImageFromFirebase()

        val countrySpinner: Spinner = findViewById(R.id.editprofile_country)
        val citySpinner: Spinner = findViewById(R.id.editprofile_city)

        ArrayAdapter.createFromResource(
            this,
            R.array.country_show,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            countrySpinner.adapter = adapter
        }

        ArrayAdapter.createFromResource(
            this,
            R.array.city_showi,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            citySpinner.adapter = adapter
        }
    }

    fun end_ac(view: View) {
        finish()
    }

    fun change_profile_details(view: View) {
        val name = findViewById<EditText>(R.id.editprofile_name)
        val newEmail = findViewById<EditText>(R.id.editprofile_email)
        val contact = findViewById<EditText>(R.id.editprofile_contactno)
        val country = findViewById<Spinner>(R.id.editprofile_country)
        val city = findViewById<Spinner>(R.id.editprofile_city)

        val currentUser = auth.currentUser
        currentUser?.let { user ->
            // Start the process to verify and update the email address
            user.verifyBeforeUpdateEmail(newEmail.text.toString()).addOnCompleteListener { verifyTask ->
                if (verifyTask.isSuccessful) {
                    // Email verification successful, now update the email address in Firebase Authentication
                    user.updateEmail(newEmail.text.toString()).addOnCompleteListener { updateEmailTask ->
                        if (updateEmailTask.isSuccessful) {
                            // Email address update successful, now update the user profile in the Realtime Database
                            db = FirebaseDatabase.getInstance().getReference().child(user.uid).child("UserInfo")
                            db.get().addOnSuccessListener { dataSnapshot ->
                                if (dataSnapshot.exists()) {
                                    val imageUrl = dataSnapshot.child("img").value.toString()
                                    val img_=dataSnapshot.child("img_b").value.toString()

                                    val userProfile = User(
                                        name.text.toString(),
                                        contact.text.toString(),
                                        newEmail.text.toString(), // Use the new email here
                                        country.selectedItem.toString(),
                                        city.selectedItem.toString(),
                                        imageUrl  // Assign the image URL here
                                    )

                                    db.setValue(userProfile).addOnCompleteListener { dbTask ->
                                        if (dbTask.isSuccessful) {
                                            // Profile update successful
                                            Toast.makeText(
                                                this,
                                                "Profile updated successfully",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        } else {
                                            // Profile update failed
                                            Toast.makeText(
                                                this,
                                                "Failed to update profile",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    }
                                }
                            }
                        } else {
                            // Email address update failed
                            Toast.makeText(this, "Failed to update email address: ${updateEmailTask.exception?.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    // Email verification failed
                    Toast.makeText(this, "Failed to verify email address: ${verifyTask.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun retrieveImageFromFirebase() {
        val currentUser = auth.currentUser
        currentUser?.let { user ->
            db = FirebaseDatabase.getInstance().getReference().child(user.uid).child("UserInfo")
            db.get().addOnSuccessListener { dataSnapshot ->
                if (dataSnapshot.exists()) {
                    val imageUrl = dataSnapshot.child("img").value.toString()

                    // Load a circular placeholder image
                    val placeholderDrawable = getCirclePlaceholderDrawable()

                    // Load the retrieved image into ImageView as a round image using Picasso
                    val i = findViewById<ImageView>(R.id.editprofile_img)
                    Picasso.get()
                        .load(imageUrl)
                        .placeholder(placeholderDrawable)
                        .transform(CircleTransform())
                        .into(i)
                }
            }.addOnFailureListener { exception ->
                Toast.makeText(this, "Failed to retrieve image: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun getCirclePlaceholderDrawable(): Drawable {
        // Create a circular placeholder drawable
        val size = 300 // Set the size of the placeholder circle
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint().apply {
            isAntiAlias = true
            color = Color.LTGRAY // Set the color of the circular placeholder
        }
        val radius = size / 2f
        canvas.drawCircle(radius, radius, radius, paint)
        return BitmapDrawable(resources, bitmap)
    }

    fun pic_select(view: View) {
        // Launch the image selection activity
        imgLauncher.launch("image/*")
    }

    fun uploadImage(imageUri: Uri) {
        val imageRef = storageref.reference.child("images/${imageUri.lastPathSegment}")
        val uploadTask = imageRef.putFile(imageUri)
        uploadTask.addOnSuccessListener { taskSnapshot ->
            imageRef.downloadUrl.addOnSuccessListener { uri ->
                val imageUrl = uri.toString()
                val currentUser = auth.currentUser
                currentUser?.let { user ->
                    db = FirebaseDatabase.getInstance().getReference().child(user.uid).child("UserInfo")
                    db.child("img").setValue(imageUrl)
                        .addOnSuccessListener {
                            Toast.makeText(this, "Image upload success", Toast.LENGTH_SHORT).show()
                            val placeholderDrawable = getCirclePlaceholderDrawable()

                            // Load the retrieved image into ImageView as a round image using Picasso
                            val i = findViewById<ImageView>(R.id.editprofile_img)
                            Picasso.get()
                                .load(imageUrl)
                                .placeholder(placeholderDrawable)
                                .transform(CircleTransform())
                                .into(i)
                        }
                        .addOnFailureListener { error ->
                            Toast.makeText(this, "Failed to update image: ${error.message}", Toast.LENGTH_SHORT).show()
                        }
                }
            }
        }.addOnFailureListener { exception ->
            Toast.makeText(this, "Image upload failed: ${exception.message}", Toast.LENGTH_SHORT).show()
        }
    }

    class CircleTransform : Transformation {
        override fun transform(source: Bitmap): Bitmap {
            val size = Math.min(source.width, source.height)

            val x = (source.width - size) / 2
            val y = (source.height - size) / 2

            val squaredBitmap = Bitmap.createBitmap(source, x, y, size, size)
            if (squaredBitmap != source) {
                source.recycle()
            }

            val bitmap = Bitmap.createBitmap(size, size, source.config)

            val canvas = Canvas(bitmap)
            val paint = Paint()
            val shader = BitmapShader(squaredBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            paint.shader = shader
            paint.isAntiAlias = true

            val radius = size / 2f
            canvas.drawCircle(radius, radius, radius, paint)

            squaredBitmap.recycle()
            return bitmap
        }

        override fun key(): String {
            return "circle"
        }
    }
}