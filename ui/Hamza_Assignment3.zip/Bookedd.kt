package com.example.ui
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.load.engine.Resource
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.squareup.picasso.Picasso
import com.squareup.picasso.Transformation

class Bookedd : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bookedd)

        val lin = findViewById<LinearLayout>(R.id.to_a)
        val auth = FirebaseAuth.getInstance().currentUser
        val db = FirebaseDatabase.getInstance().getReference().child("Users").child(auth!!.uid).child("Bookings")

        db.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                lin.removeAllViews() // Clear existing views

                for (bookingSnapshot in snapshot.children) {
                    val book_gigd = layoutInflater.inflate(R.layout.profile_boo, null)
                    val name_ofperson = book_gigd.findViewById<TextView>(R.id.book_name)
                    val job_ofp = book_gigd.findViewById<TextView>(R.id.book_job)
                    val date_ofp = book_gigd.findViewById<TextView>(R.id.book_date)
                    val time_ofp = book_gigd.findViewById<TextView>(R.id.book_time)
                    val img = book_gigd.findViewById<ImageView>(R.id.book_img)

                    val date = bookingSnapshot.child("date").value.toString()
                    val time = bookingSnapshot.child("time").value.toString()
                    val uid_to = bookingSnapshot.child("uid_to").value.toString()

                    // Get the user's data from Firebase
                    val userRef = FirebaseDatabase.getInstance().getReference().child("Users").child(uid_to)
                    userRef.addValueEventListener(object : ValueEventListener {
                        override fun onDataChange(userSnapshot: DataSnapshot) {
                            val userName =
                                userSnapshot.child("UserInfo").child("name").value.toString()
                            val userJob = userSnapshot.child("gig").child("job").value.toString()

                            name_ofperson.text = userName
                            job_ofp.text = userJob

                            val imageUrl =
                                userSnapshot.child("UserInfo").child("img").value.toString()
                            Picasso.get()
                                .load(imageUrl)
                                .transform(RoundedTransformation(8f))
                                .fit()
                                .into(img)
                        }

                        override fun onCancelled(error: DatabaseError) {
                            // Handle onCancelled event (optional)
                        }
                    })

                    date_ofp.text = date
                    time_ofp.text = time

                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    params.setMargins(10, 20, 10, 20)
                    book_gigd.layoutParams = params

                    lin.addView(book_gigd)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle onCancelled event (optional)
            }
        })
    }

    fun end_ac(view: View) {
        finish()
    }
    class RoundedTransformation(private val radius: Float) : Transformation {
        override fun transform(source: Bitmap): Bitmap {
            val bitmap = Bitmap.createBitmap(source.width, source.height, source.config)
            val canvas = Canvas(bitmap)
            val paint = Paint()
            paint.isAntiAlias = true
            val rect = Rect(0, 0, source.width, source.height)
            val rectF = RectF(rect)
            canvas.drawRoundRect(rectF, radius, radius, paint)
            paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
            canvas.drawBitmap(source, rect, rect, paint)
            source.recycle()
            return bitmap
        }

        override fun key(): String = "rounded(radius=$radius)"
    }
}