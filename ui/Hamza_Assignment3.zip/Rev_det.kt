package com.example.ui

class Rev_det(
    var user_from:String?="",
    var name:String?="",
    var review:String?="",
    var stars:Int?=5
) {
}