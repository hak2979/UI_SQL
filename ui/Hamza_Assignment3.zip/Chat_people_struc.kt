package com.example.ui

class Chat_people_struc(
    val name:String?="",
    val img:String?="",
    val uid:String?=""
) {
}