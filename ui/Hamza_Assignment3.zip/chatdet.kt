package com.example.ui

class chatdet(
    val sender:String?="",
    val recv:String?="",
    val msg:String?="",
    val msgType:String?="",
    val msgid:String?="",
    val timestamp: Long? = null
) {
}