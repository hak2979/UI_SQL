package com.example.ui

data class gig_d(
    val name: String = "",
    val price: String = "",
    val experience: String = "",
    val uid:String?="",
    val isAvailable: Boolean = false
)