package com.example.ui

class Gig(var field:String?="",
          var des:String?="",
          var session:String?="",
          var job:String?="") {
}